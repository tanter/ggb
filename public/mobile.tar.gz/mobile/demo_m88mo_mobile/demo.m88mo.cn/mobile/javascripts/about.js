$(function(){
	$(".relation").click(function(){
		window.location.href=_SERVER+'order.html';
	})
	$(".policy").click(function(){
		window.location.href=_SERVER+'policy.html';
	})

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
})
