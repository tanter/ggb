$(function(){
	$(".imgRight").click(function(){
		window.location.href=_SERVER+'relation.html';
	});
	$(".imgLeft").click(function(){
		window.history.back(-1); 
	})

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
})